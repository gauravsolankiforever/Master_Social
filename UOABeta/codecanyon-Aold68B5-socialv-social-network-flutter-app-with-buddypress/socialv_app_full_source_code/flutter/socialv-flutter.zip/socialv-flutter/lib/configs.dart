/// App Name
const APP_NAME = "SocialV";

/// App Icon src
const APP_ICON = "assets/app_icon.png";

/// Splash screen image src
const SPLASH_SCREEN_IMAGE = 'assets/images/splash_image.png';

/// OneSignal Notification App Id
const ONESIGNAL_APP_ID = '';

/// Todo: Remove Base URL
/// NOTE: Do not add slash (/) at the end of your domain.
const DOMAIN_URL = '';
//const DOMAIN_URL = 'http://192.168.1.230/wp_themes/latest/socialv';
const BASE_URL = '$DOMAIN_URL/wp-json/';

/// Terms and Conditions URL
const TERMS_AND_CONDITIONS_URL = '$DOMAIN_URL/terms-condition/';

/// Privacy Policy URL
const PRIVACY_POLICY_URL = '$DOMAIN_URL/privacy-policy-2/';

/// Support URL
const SUPPORT_URL = 'https://iqonic.desky.support';

/// AdMod Id
const mAdMobAppId = 'ca-app-pub-8466012735057920~2016126698';
const mAdMobBannerId = 'ca-app-pub-8466012735057920/2946064985';
